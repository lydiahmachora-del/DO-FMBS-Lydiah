# DO-FMBS install, run, and verify

This source package lets you create a fresh DO-FMBS run on your own computer. It intentionally does not include generated datasets, trained models, prior run folders, or accepted research evidence. New results are generated locally and are not automatically equivalent to the researcher's previously accepted runs.

## Requirements

- Windows 10/11 (the included `setup_and_run.bat` is the easiest path).
- Python 3.9, 3.10, or 3.11; Python 3.11 is recommended. The setup script attempts to install it if no compatible version is found.
- Internet access for dependency installation and the first LFW face-data download.
- At least 8 GB RAM; 16 GB recommended. CPU execution works; a GPU is optional.
- Allow substantial time for all six phases. Training and verification may take several minutes or longer depending on the computer.

## Install and launch

1. Extract the ZIP to a writable local folder (avoid running it inside the ZIP or a protected Windows directory).
2. Double-click `setup_and_run.bat` and allow it to create the virtual environment and install dependencies.
3. When the browser opens, choose **New Interactive Run** in the sidebar.
4. Run each phase in order, starting with Phase 1. Wait for a phase to report successful completion before starting the next one. The page shows live execution logs and the generated outputs after each phase.
5. After Phase 6, the dashboard stores the run's files under `runtime_recording/interactive_replay_<timestamp>/`.

The dependency file pins NumPy and PyArrow to versions compatible with TensorFlow 2.13. Avoid independently upgrading NumPy or PyArrow in this environment; incompatible major versions can prevent Streamlit tables from rendering.

Fingerprint images are generated synthetically by the application; they are not downloaded from a fingerprint database. Face images are acquired from the public LFW dataset through scikit-learn. The independent identity spaces are not person-level multimodal pairs. Consult `README.md` for the research scope and limitations.

## Independently verify a completed run

Open PowerShell in the extracted project folder. Replace the example run folder with the exact folder name created on your computer:

```powershell
& .\venv\Scripts\python.exe .\scripts\verify_replay_evidence.py `
  --run-dir .\runtime_recording\interactive_replay_YYYYMMDD_HHMMSS
```

The verifier independently checks the saved train/calibration/test partitions, scaler fit indices, confusion-matrix totals, verification FAR/FRR arithmetic, fingerprint identity split, fingerprint quality gate, Phase 4 fingerprint gradients, and privacy terminology. A successful check prints `Independent replay audit: PASS` and saves `independent_replay_audit.json` in that run's `do_fmbs_data` folder. If it fails, preserve the run and its logs for investigation rather than editing its results.

Generated datasets, models, plots, CSV/JSON reports, execution logs, and the audit file remain in the run folder. They can then be reviewed or copied separately from the source ZIP.
